
// ChatRail Content Script (Unified Version)
// Logic integrated into index.js to support multi-platforms including Doubao, Grok, and Yuanbao.
